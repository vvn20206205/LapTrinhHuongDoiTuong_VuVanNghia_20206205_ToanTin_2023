using System.Collections.Generic;

namespace ChessGame.Core
{
    internal struct ResultBoards
    {       
        internal List<Board> Positions;        
    }
}
