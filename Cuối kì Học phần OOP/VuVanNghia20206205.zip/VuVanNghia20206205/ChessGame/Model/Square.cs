﻿namespace ChessGame.Model;
public class Square { public Piece Piece; }