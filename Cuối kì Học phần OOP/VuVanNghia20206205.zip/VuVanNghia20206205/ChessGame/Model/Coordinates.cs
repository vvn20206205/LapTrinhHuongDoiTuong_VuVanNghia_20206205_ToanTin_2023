﻿namespace ChessGame.Model;
public struct Coordinates { public static readonly Square[,] Board = new Square[8, 8]; }