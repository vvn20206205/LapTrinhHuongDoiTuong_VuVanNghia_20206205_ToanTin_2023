﻿using System.Drawing;

namespace ChessGame.Controller;
public interface IControl
{
    void Start();
    bool Select(Point coordinate);
}