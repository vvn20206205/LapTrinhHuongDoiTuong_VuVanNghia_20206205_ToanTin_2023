﻿using System.ComponentModel;
using System.Windows.Forms;

namespace ChessGame.View
{
    partial class MainMenuView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_StartBlackVsComputerGame = new Button();
            label1 = new Label();
            button_StartWhiteVsComputerGame = new Button();
            button_StartHumanGame = new Button();
            SuspendLayout();
            // 
            // button_StartBlackVsComputerGame
            // 
            button_StartBlackVsComputerGame.Dock = DockStyle.Bottom;
            button_StartBlackVsComputerGame.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button_StartBlackVsComputerGame.Location = new System.Drawing.Point(0, 211);
            button_StartBlackVsComputerGame.Margin = new Padding(50, 0, 50, 0);
            button_StartBlackVsComputerGame.Name = "button_StartBlackVsComputerGame";
            button_StartBlackVsComputerGame.Size = new System.Drawing.Size(284, 50);
            button_StartBlackVsComputerGame.TabIndex = 3;
            button_StartBlackVsComputerGame.Text = "Quân đen chơi với máy";
            button_StartBlackVsComputerGame.UseVisualStyleBackColor = true;
            button_StartBlackVsComputerGame.Click += Button_StartBlackVsComputerGame_Click;
            // 
            // label1
            // 
            label1.Dock = DockStyle.Top;
            label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(0, 0);
            label1.Margin = new Padding(0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(284, 50);
            label1.TabIndex = 100;
            label1.Text = "Chọn chế độ chơi";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_StartWhiteVsComputerGame
            // 
            button_StartWhiteVsComputerGame.Dock = DockStyle.Bottom;
            button_StartWhiteVsComputerGame.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button_StartWhiteVsComputerGame.Location = new System.Drawing.Point(0, 161);
            button_StartWhiteVsComputerGame.Margin = new Padding(50, 0, 50, 0);
            button_StartWhiteVsComputerGame.Name = "button_StartWhiteVsComputerGame";
            button_StartWhiteVsComputerGame.Size = new System.Drawing.Size(284, 50);
            button_StartWhiteVsComputerGame.TabIndex = 2;
            button_StartWhiteVsComputerGame.Text = "Quân trắng chơi với máy";
            button_StartWhiteVsComputerGame.UseVisualStyleBackColor = true;
            button_StartWhiteVsComputerGame.Click += Button_StartWhiteVsComputerGame_Click;
            // 
            // button_StartHumanGame
            // 
            button_StartHumanGame.Dock = DockStyle.Bottom;
            button_StartHumanGame.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button_StartHumanGame.Location = new System.Drawing.Point(0, 111);
            button_StartHumanGame.Margin = new Padding(50, 0, 50, 0);
            button_StartHumanGame.Name = "button_StartHumanGame";
            button_StartHumanGame.Size = new System.Drawing.Size(284, 50);
            button_StartHumanGame.TabIndex = 1;
            button_StartHumanGame.Text = "2 người chơi";
            button_StartHumanGame.UseVisualStyleBackColor = true;
            button_StartHumanGame.Click += Button_StartHumanGame_Click;
            // 
            // MainMenuView
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            ClientSize = new System.Drawing.Size(284, 261);
            Controls.Add(button_StartHumanGame);
            Controls.Add(button_StartWhiteVsComputerGame);
            Controls.Add(label1);
            Controls.Add(button_StartBlackVsComputerGame);
            Name = "MainMenuView";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "VuVanNghia20206205";
            ResumeLayout(false);
        }

        #endregion
        private Button button_StartBlackVsComputerGame;
        private Label label1;
        private Button button_StartWhiteVsComputerGame;
        private Button button_StartHumanGame;
    }
}